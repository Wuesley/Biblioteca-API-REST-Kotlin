package com.biblioteca.apibiblioteca

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ApibibliotecaApplicationTests {

	@Test
	fun contextLoads() {
	}

}
